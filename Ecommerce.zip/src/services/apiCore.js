import { apiProvider } from "./provider";

const getToken = () => localStorage.getItem('token');

const addAuthHeader = (config = {}) => {
  const token = getToken();
  if (token) {
    config.headers = {
      ...config.headers,
      Authorization: `Bearer ${token}`,
    };
  }
  return config;
};

const apiCore = {
  getAll(url, cancelToken) {
    const config = addAuthHeader({ cancelToken });
    return apiProvider.getAll(url, config);
  },
  getDataById(url, id) {
    const config = addAuthHeader();
    return apiProvider.getDataById(url, id, config);
  },
  postCall(url, payload) {
    const config = addAuthHeader();
    return apiProvider.postCall(url, payload, config);
  },
  postCallById(url, id, payload) {
    const config = addAuthHeader();
    return apiProvider.postCallById(url, id, payload, config);
  },
  removeCall(url, payload) {
    const config = addAuthHeader();
    return apiProvider.removeCall(url, payload, config);
  },
  updateCall(url, payload) {
    const config = addAuthHeader();
    return apiProvider.updateCall(url, payload, config);
  },
  updateCallById(url, id, payload) {
    const config = addAuthHeader();
    return apiProvider.updateCallById(url, id, payload, config);
  },
};

export default apiCore;
