const config = {
    devApi: {
        spcHostUrl: "https://localhost:7137/api/"
    },

    api: {
        login: "Authentication/login",
        register: "Authentication/register",
        GetProducts: "Products/GetProducts",
        DeleteProduct: (Id) => `Products/DeleteProduct/${Id}`,
        UpdateProduct : (Id) => `https://localhost:7137/api/Products/Update/${Id}`,
        CreateOrder : "Orders/CreateOrder",
        CreateProduct : "https://localhost:7137/api/Products/CreateProduct"
    }
}
export default config;