import axios from "axios";
import { handleError, handleErrorWithStatus, handleResponse, handleResponseWithStatus } from "./response";
import config from './config';

const getBaseUrl = (resource) => {
    return resource.includes('http') || resource.includes('https') ? resource : config.devApi.spcHostUrl + resource;
}

const getBaseUrlById = (resource, id) => {
    return resource.includes('http') || resource.includes('https') ? resource : config.devApi.spcHostUrl + resource + id;
}

const getAll = (resource, config) => {
    return axios
        .get(getBaseUrl(resource), config)
        .then(handleResponse)
        .catch(handleError);
}

const getDataById = (resource, id, config) => {
    return axios
        .get(getBaseUrlById(resource, id), config)
        .then(handleResponseWithStatus)
        .catch(handleErrorWithStatus);
}

const postCall = (resource, payload, config) => {
    return axios
        .post(getBaseUrl(resource), payload, config)
        .then(handleResponse)
        .catch(handleError);
}

const postCallById = (resource, id, payload, config) => {
    return axios
        .post(getBaseUrlById(resource, id), payload, config)
        .then(handleResponse)
        .catch(handleError);
}

const updateCall = (resource, payload, config) => {
    return axios
        .put(getBaseUrl(resource), payload, config)
        .then(handleResponse)
        .catch(handleError);
}

const updateCallById = (resource, id, payload, config) => {
    return axios
        .put(getBaseUrlById(resource, id), payload, config)
        .then(handleResponse)
        .catch(handleError);
}

const removeCall = (resource, payload, config) => {
    return axios
        .delete(getBaseUrl(resource), {
            ...config,
            data: payload,
        })
        .then(handleResponse)
        .catch(handleError);
}

export const apiProvider = {
    getAll,
    getDataById,
    postCall,
    postCallById,
    updateCall,
    updateCallById,
    removeCall
}
