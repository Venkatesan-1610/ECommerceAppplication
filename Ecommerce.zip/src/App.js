import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { CartProvider } from "./components/slices/CartContext";
import LoginForm from "./components/auth/LoginForm";
import RegistrationForm from "./components/auth/RegistrationForm";
import ProductList from "./components/products/ProductList";
import Layout from "./components/layout/Layout";
import Unauthorized from "./components/main/Unauthorized";
import About from "./components/main/About";
import Cart from "./components/products/Cart";
import Home from "./components/main/Home";
import PlaceOrder from "./components/orders/PlaceOrder";
import OrderConfirmation from "./components/orders/OrderConfirmation";
import AuthGuard from "./components/auth/AuthGuard";
import CreateProduct from "../src/components//products/CreateProduct"
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [role, setRole] = useState("");

  const checkAuth = () => {
    const token = localStorage.getItem("token");
    const userRole = localStorage.getItem("role");

    setIsAuthenticated(!!token); 
    setRole(userRole || ""); 
  };

  useEffect(() => {
    checkAuth(); 
  }, []);

  return (
    <Router>
      <CartProvider>
        <div className="App">
          <Layout isAuthenticated={isAuthenticated} role={role}>
            <Routes>
              <Route path="/" element={<Home isAuthenticated={isAuthenticated} />} />
              <Route path="/login" element={<LoginForm checkAuth={checkAuth} />} />
              <Route path="/register" element={<RegistrationForm checkAuth={checkAuth}/>} />
              <Route
                path="/products"
                element={
                  <AuthGuard isAuthenticated={isAuthenticated} roles={['Admin', 'User']} element={<ProductList role={role} />} />
                }
              />
              <Route path="/unauthorized" element={<Unauthorized />} />
              <Route path="/about" element={<About />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/placeorder" element={<PlaceOrder />} />
              <Route path="/orderconfirmation" element={<OrderConfirmation />} />
              <Route path="/createproduct" element={<CreateProduct />} />
            </Routes>
          </Layout>
          <ToastContainer /> 
        </div>
      </CartProvider>
    </Router>
  );
}

export default App;
