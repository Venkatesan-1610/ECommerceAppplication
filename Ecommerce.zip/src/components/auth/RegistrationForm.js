import React  from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import services from "../../services";
import config from "../../services/config";
import '../../styles/RegistrationForm.css';
import showToast from '../../services/ToastService.js';

const RegistrationForm = ({ checkAuth }) => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const navigate = useNavigate();


  
  const onSubmit = async (data) => {
    try {
      const registerEndpoint = config.api.register;
      const response = await services.serviceApiCall.postCall(registerEndpoint, data);
  
      if (response) {
        console.log(response,'Registration successful');
        showToast('User registered successfully', 'success');
        checkAuth();
        navigate('/products');
      }
      else {
        showToast('Something went wrong try agaiin later', 'warning');
      }
    } catch (error) {
      console.error("Error registering user:", error);
      if (error.response && error.response.status === 409) {
        showToast('User already registered with this email', 'warning');
      } else {
        showToast('Failed to register user', 'error');
      }
    }
  };
  

  return (
    <div className="registration-form-container">
      <h2>Register</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="form-group">
          <label>Username</label>
          <input type="text" {...register('username', { required: true })} placeholder="Enter your username" />
          {errors.username && <span className="error-message">Username is required</span>}
        </div>
        <div className="form-group">
          <label>Email</label>
          <input type="email" {...register('email', { required: true })} placeholder="Enter your email" />
          {errors.email && <span className="error-message">Email is required</span>}
        </div>
        <div className="form-group">
          <label>Password</label>
          <input type="password" {...register('password', { required: true })} placeholder="Enter your password" />
          {errors.password && <span className="error-message">Password is required</span>}
        </div>
        {/* {errorMessage && <div className="error-message">{errorMessage}</div>} */}
        <button type="submit" className="btn btn-primary">Register</button>
      </form>
    </div>
  );
};

export default RegistrationForm;
