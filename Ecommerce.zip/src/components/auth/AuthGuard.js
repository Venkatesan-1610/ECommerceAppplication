import React from 'react';
import { Navigate } from 'react-router-dom';

const AuthGuard = ({ element, roles }) => {
  const getUserRole = () => {
    const userRole = localStorage.getItem("role");
    return userRole || "";
  };

  const userRole = getUserRole();

  const hasRequiredRole = () => {
    if (!roles || roles.length === 0) return true; 
    return roles.includes(userRole); 
  };

  if (!userRole) {
    return <Navigate to="/login" />;
  }

  if (!hasRequiredRole()) {
    return <Navigate to="/login" />;
  }

  return element;
};

export default AuthGuard;
