import React from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import services from "../../services";
import config from "../../services/config";
import showToast from '../../services/ToastService';
import '../../styles/LoginForm.css';

const LoginForm = ({ checkAuth }) => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    try {
      const loginEndpoint = config.api.login;
      const response = await services.serviceApiCall.postCall(loginEndpoint, data);
      if (response.token) {
        console.log(response.token)
        localStorage.setItem('token', response.token);
        localStorage.setItem('role', response.role);
        showToast('Login successful', 'success');
        checkAuth();
        navigate('/products');
      }
      else {
        showToast('Please check your email id or password', 'warning');
      }
    } catch (error) {
      console.error('Error logging in:', error);
      if (error.response || error.response.status === 404) {
        showToast('User not found. Please register.', 'warning');
      } else {
        showToast('Failed to log in', 'error');
      }
    }
  };

  const handleRegisterRedirect = () => {
    navigate('/register');
  };

  return (
    <div className="login-form-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="form-group">
          <label>Email</label>
          <input type="email" {...register('email', { required: true })} placeholder="Enter your email" />
          {errors.email && <span className="error-message">Email is required</span>}
        </div>
        <div className="form-group">
          <label>Password</label>
          <input type="password" {...register('password', { required: true })} placeholder="Enter your password" />
          {errors.password && <span className="error-message">Password is required</span>}
        </div>
        <button type="submit" className="btn btn-primary">Login</button>
        <button type="button" className="btn btn-secondary" onClick={handleRegisterRedirect}>Register</button>
      </form>
    </div>
  );
};

export default LoginForm;
