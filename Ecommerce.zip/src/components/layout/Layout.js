import React from 'react';
import NavBar from '../main/Navbar';

const Layout = ({ children, isAuthenticated, role }) => {
  return (
    <div>
      <NavBar isAuthenticated={isAuthenticated} role={role} />
      <div className="content">{children}</div>
    </div>
  );
};

export default Layout;
