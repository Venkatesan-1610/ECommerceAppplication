import React, { createContext, useState, useContext } from 'react';
import showToast from '../../services/ToastService';

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    if (cart.some(item => item.id === product.id)) {
      showToast('Product already in cart', 'warning');
    } else {
      setCart(prevCart => [...prevCart, product]);
    }
  };

  const removeFromCart = (productId) => {
    setCart(prevCart => prevCart.filter(product => product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, clearCart }}>
      {children}
    </CartContext.Provider>
  );
};
