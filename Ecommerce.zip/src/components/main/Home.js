import React from "react";
import { useNavigate } from "react-router-dom";
import '../../styles/Home.css';

const Home = ({ isAuthenticated }) => {
  const navigate = useNavigate();

  const handleBrowseClick = () => {
    if (isAuthenticated) {
      navigate('/products');
    } else {
      navigate('/login');
    }
  };

  return (
    <div className="home-container">
      <div className="home-content">
        <h1>Welcome to Product Management App</h1>
        <p>
          This app allows you to manage products efficiently. Admin users can manage the product list, while regular users can browse through the products.
        </p>
        <div className="home-buttons">
          <button onClick={handleBrowseClick} className="btn btn-primary">Browse Products</button>
          <a href="/about" className="btn btn-secondary">Learn More</a>
        </div>
      </div>
    </div>
  );
};

export default Home;