import React from "react";
import "../../styles/About.css";

function About() {
  return (
    <div className="about-container m-5 p-5">
      <h1>About Our Product Management Application</h1>
      <p>
        Welcome to our Product Management Application! This app is designed to
        help you manage your products efficiently and effectively. Whether
        you're managing a small inventory or a large catalog, our app provides
        all the necessary tools to streamline your product management process.
      </p>
      <h2>Features</h2>
      <ul>
        <li>Add, update, and delete products with ease.</li>
        <li>Organize products into categories for better organization and accessibility.</li>
        <li>Track inventory levels and receive alerts for low stock.</li>
        <li>Generate detailed reports to analyze product performance and sales trends.</li>
        <li>Securely store product information with state-of-the-art encryption.</li>
      </ul>
      <h2>About Our Team</h2>
      <p>
        Our team is dedicated to providing the best possible user experience. We
        continuously work on improving the app and adding new features based on
        user feedback. If you have any suggestions or feedback, please do not
        hesitate to reach out to us.
      </p>
      <p>
        Contact us at:{" "}
        <a href="mailto:support@productapp.com">support@productapp.com</a>
      </p>
    </div>
  );
}

export default About;
