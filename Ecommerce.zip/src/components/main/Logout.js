import React from "react";
import { useNavigate } from "react-router-dom";
import showToast from "../../services/ToastService";

const Logout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    showToast("Logged out successfully", "success");
    window.location.reload();
    navigate("/");
  };

  return (
    <button onClick={handleLogout} className="btn btn-primary">
      Logout
    </button>
  );
};

export default Logout;
