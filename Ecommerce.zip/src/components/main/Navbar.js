import React from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../styles/Navbar.css";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import Logout from "./Logout";
import { useCart } from "../slices/CartContext";

const NavBar = ({ isAuthenticated, role }) => {
  const { cart } = useCart(); 

  return (
    <div className="navbar_wrapper">
      <div className="container">
        <div className="navbar_container">
          <div className="d-flex align-items-center">
            <div className="d-flex align-items-center title">
              <h5>Product Management</h5>
            </div>
          </div>
          <div className="d-flex align-items-center">
            <ul>
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/about">About</Link>
              </li>
              {!isAuthenticated &&(
                <li>
                <Link to="/login">Login</Link>
              </li>
              ) }
              
              {isAuthenticated && role === 'User' && (
                <li>
                  <Link to="/products">Products</Link>
                </li>
              )}
              {isAuthenticated && role === 'Admin' && (
                <li>
                  <Link to="/products">Manage Products</Link>
                </li>
              )}
              {isAuthenticated && (
                <li>
                  <Link to="/cart" className="cart-link">
                    <FontAwesomeIcon icon={faShoppingCart} />
                    {cart.length > 0 && (
                      <span className="cart-badge">{cart.length}</span>
                    )}
                  </Link>
                </li>
              )}
              {isAuthenticated && (
                <li>
                  <Logout />
                </li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NavBar;
