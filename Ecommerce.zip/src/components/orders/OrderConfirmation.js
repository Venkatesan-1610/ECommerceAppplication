import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useCart } from '../slices/CartContext';
import '../../styles/OrderConfirmation.css';

const OrderConfirmation = () => {
  const location = useLocation();
  const { orderData } = location.state || {};
  const { clearCart } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    if (orderData) {
      clearCart();
    }
  }, [orderData]);

  console.log(orderData);

  if (!orderData) {
    return <div className="container">No order details found.</div>;
  }

  const { name, mobile, address, price, productName, productDescription } = orderData;

  return (
    <div className="order-confirmation-container">
      <div className="order-confirmation-bill">
        <h2>Order Confirmation</h2>
        <hr />
        <div className="info-section">
          <h5>Customer Information</h5>
          <p><strong>Name:</strong> {name}</p>
          <p><strong>Mobile Number:</strong> {mobile}</p>
          <p><strong>Address:</strong> {address}</p>
        </div>
        <hr />
        <div className="info-section">
          <h5>Product Information</h5>
          <p><strong>Product:</strong> {productName || 'Product name not available'}</p>
          <p><strong>Description:</strong> {productDescription || 'Description not available'}</p>
          <p><strong>Price:</strong> ${price}</p>
        </div>
        <hr />
        <p className="total"><strong>Total:</strong> ${price}</p>
        <button onClick={() => navigate('/')} className="btn btn-primary mt-3">Back to Home</button>
      </div>
    </div>
  );
};

export default OrderConfirmation;
