import React from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate, useLocation } from 'react-router-dom';
import {jwtDecode} from 'jwt-decode';
import services from "../../services";
import config from "../../services/config";
import showToast from '../../services/ToastService';

const PlaceOrder = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const navigate = useNavigate();
  const location = useLocation();
  const { product } = location.state || {};

  const { id, name, description, price } = product.updatedProductData || product;

  const onSubmit = async (data) => {
    const token = localStorage.getItem('token');
    if (!token) {
      showToast('User not authenticated', 'error');
      navigate('/login');
      return;
    }

    const decodedToken = jwtDecode(token);
    const userId = decodedToken.userId;

    const orderData = {
      userId,
      productId: id,
      quantity: 1,
      price,
      name: data.name,
      mobile: data.mobile,
      address: data.address,
      productName: name,
      productDescription: description,
    };

    try {
      const CreateOrderEndpoint = config.api.CreateOrder;
      const response = await services.serviceApiCall.postCall(CreateOrderEndpoint, orderData, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      if (response) {
        showToast('Order placed successfully', 'success');
        navigate('/orderconfirmation', { state: { orderData } });
      } else {
        showToast('Failed to place order', 'error');
      }
    } catch (error) {
      console.error('Error placing order:', error);
      showToast('Failed to place order', 'error');
    }
  };

  console.log(product, 'product');

  return (
    <div className="container bill-container">
      <h2 className="text-center mb-4">Order Summary</h2>
      <div className="bill-card">
        <h5>Product: {name}</h5>
        <p>Description: {description}</p>
        <p>Price: ${price}</p>
        <hr />
        <h4>Total: ${price}</h4>

        <form onSubmit={handleSubmit(onSubmit)} className="order-form">
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              id="name"
              className={`form-control ${errors.name ? 'is-invalid' : ''}`}
              {...register('name', { required: 'Name is required' })}
            />
            {errors.name && <div className="invalid-feedback">{errors.name.message}</div>}
          </div>
          <div className="form-group">
            <label htmlFor="mobile">Mobile Number</label>
            <input
              type="text"
              id="mobile"
              className={`form-control ${errors.mobile ? 'is-invalid' : ''}`}
              {...register('mobile', {
                required: 'Mobile number is required',
                pattern: {
                  value: /^[0-9]{10}$/,
                  message: 'Mobile number must be 10 digits'
                }
              })}
            />
            {errors.mobile && <div className="invalid-feedback">{errors.mobile.message}</div>}
          </div>
          <div className="form-group">
            <label htmlFor="address">Address</label>
            <textarea
              id="address"
              className={`form-control ${errors.address ? 'is-invalid' : ''}`}
              {...register('address', { required: 'Address is required' })}
            />
            {errors.address && <div className="invalid-feedback">{errors.address.message}</div>}
          </div>
          <button type="submit" className="btn btn-primary mt-3">Place Order</button>
        </form>
      </div>
    </div>
  );
};

export default PlaceOrder;
