import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'; 
import { useCart } from '../slices/CartContext';
import services from "../../services";
import config from "../../services/config";
import showToast from '../../services/ToastService';
import '../../styles/ProductList.css';
import iphoneImage from '../../images/iphone_13.png';

const ProductList = ({ role }) => {
  const [products, setProducts] = useState([]);
  const { addToCart } = useCart();
  const serviceApiCall = services.serviceApiCall;
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetchData();
  },[] );

  const fetchData = async () => {
    try {
      const getProductsEndpoint = config.api.GetProducts;
      const response = await serviceApiCall.getAll(getProductsEndpoint);
      if (response && Array.isArray(response)) {
        setProducts(response.map(product => ({ ...product, isEditing: false, updatedProductData: { ...product } })));
      }
    } catch (error) {
      showToast('Failed to fetch products', 'error');
    }
  };

  const handleDelete = async (productId) => {
    try {
      if (token) {
        const deleteUrl = config.api.DeleteProduct(productId);
        await serviceApiCall.removeCall(deleteUrl, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setProducts(products.filter(product => product.id !== productId));
        showToast('Product deleted successfully', 'success');
      } else {
        showToast('Unauthorized to delete product', 'error');
      }
    } catch (error) {
      console.error("Error deleting product:", error);
      showToast('Failed to delete product', 'error');
    }
  };

  const handleUpdate = async (productId, updatedProductData) => {
    try {
      const updateUrl = config.api.UpdateProduct(productId);

      if (!token) {
        throw new Error('No authorization token found');
      }

      const requestOptions = {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(updatedProductData)
      };

      const response = await fetch(updateUrl, requestOptions);
      if (!response.ok) {
        throw new Error('Failed to update product');
      }

      const updatedProductResponse = await response.json();
      console.log(updatedProductResponse, 'updatedProductResponse');
      showToast('Product updated successfully', 'success');
      fetchData();
    } catch (error) {
      console.error("Error updating product:", error);
      showToast('Failed to update product', 'error');
    }
  };

  const handleInputChange = (productId, columnName, value) => {
    setProducts(products.map(product => {
      if (product.id === productId) {
        return { ...product, updatedProductData: { ...product.updatedProductData, [columnName]: value } };
      }
      return product;
    }));
  };

  const toggleEditing = (productId) => {
    setProducts(products.map(product => {
      if (product.id === productId) {
        return { ...product, isEditing: !product.isEditing };
      }
      return product;
    }));
  };

  return (
    <div className="container">
      <h2 className="text-center mb-4">Product List</h2>
      {role === 'Admin' && (
        <div className="mb-4">
          <Link to="/createproduct" className="btn btn-primary">Create New Product</Link>
        </div>
      )}
      <br />
      <div className="row">
        {products.map(product => (
          <div className="col-md-4 mb-4" key={product.id}>
            <div className="card product-card">
              <img src={iphoneImage} className="card-img-top" alt={product.name} />
              <div className="card-body">
                {product.isEditing ? (
                  <>
                    <input type="text" value={product.updatedProductData.name} onChange={(e) => handleInputChange(product.id, 'name', e.target.value)} />
                    <input type="text" value={product.updatedProductData.description} onChange={(e) => handleInputChange(product.id, 'description', e.target.value)} />
                    <input type="number" value={product.updatedProductData.price} onChange={(e) => handleInputChange(product.id, 'price', e.target.value)} />
                    <input type="number" value={product.updatedProductData.stock} onChange={(e) => handleInputChange(product.id, 'stock', e.target.value)} />
                    <button className="btn btn-success" onClick={() => handleUpdate(product.id, product.updatedProductData)}>Save</button>
                  </>
                ) : (
                  <>
                    <h5 className="card-title">{product.name}</h5>
                    <p className="card-text">{product.description}</p>
                    <p className="card-text">Price: ${product.price}</p>
                    <p className="card-text">Stock: {product.stock}</p>
                    <button className="btn btn-primary" onClick={() => addToCart(product)}>Add to Cart</button>
                    {role === 'Admin' && (
                      <>
                        <button className="btn btn-danger" onClick={() => handleDelete(product.id)}>Delete</button>
                        <button className="btn btn-warning" onClick={() => toggleEditing(product.id)}>Update</button>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;
