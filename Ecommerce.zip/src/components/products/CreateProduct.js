import React, { useState } from 'react';
import config from "../../services/config";
import showToast from '../../services/ToastService';
import "../../styles/CreateProduct.css";
import { useNavigate } from 'react-router';

const CreateProduct = () => {
  const token = localStorage.getItem('token');
  const createProductEndpoint = config.api.CreateProduct;
  const navigate = useNavigate();

  const [newProduct, setNewProduct] = useState({
    name: '',
    description: '',
    price: '',
    stock: ''
  });

  const handleNewProductChange = (e) => {
    const { name, value } = e.target;
    setNewProduct(prevState => ({ ...prevState, [name]: value }));
  };

  const handleCreateProduct = async (e) => {
    e.preventDefault();
    try {
      if (!token) {
        throw new Error('No authorization token found');
      }

      const requestOptions = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newProduct)
      };

      await fetch(createProductEndpoint, requestOptions);

    //   if (!response.ok) {
    //     const errorMessage = await response.text();
    //     throw new Error(`HTTP error! Status: ${response.status}. Message: ${errorMessage}`);
    //   }

    //   const createdProduct = await response.json();

    //   if (!createdProduct || Object.keys(createdProduct).length === 0) {
    //     throw new Error('Empty response or invalid product data');
    //   }

    //   console.log(createdProduct, 'createdProduct');

      showToast('Product created successfully', 'success');
      navigate("/products");
      setNewProduct({ name: '', description: '', price: '', stock: '' });

    } catch (error) {
      console.error("Error creating product:", error.message);
      showToast('Failed to create product', 'error');
    }
  };

  return (
    <div className="create-product-form">
      <h3>Create New Product</h3>
      <form onSubmit={handleCreateProduct}>
        <div className="form-group">
          <label htmlFor="name">Product Name</label>
          <input type="text" id="name" name="name" className="form-control" value={newProduct.name} onChange={handleNewProductChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="description">Description</label>
          <input type="text" id="description" name="description" className="form-control" value={newProduct.description} onChange={handleNewProductChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="price">Price</label>
          <input type="number" id="price" name="price" className="form-control" value={newProduct.price} onChange={handleNewProductChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="stock">Stock</label>
          <input type="number" id="stock" name="stock" className="form-control" value={newProduct.stock} onChange={handleNewProductChange} required />
        </div>
        <button type="submit" className="btn btn-primary">Create Product</button>
      </form>
    </div>
  );
};

export default CreateProduct;
