import React from 'react';
import { useCart } from '../slices/CartContext';
import { useNavigate } from 'react-router-dom';

const Cart = () => {
  const { cart, removeFromCart } = useCart();
  const navigate = useNavigate();

  const handleBuy = (product) => {
    navigate('/placeorder', { state: { product } });
  };

  return (
    <div className="container">
      <h2 className="text-center mb-4">Your Cart</h2>
      <div className="row">
        {cart.map(product => (
          <div className="col-md-4 mb-4" key={product.id}>
            <div className="card product-card">
              <div className="card-body">
                <h5 className="card-title">{product.name}</h5>
                <p className="card-text">{product.description}</p>
                <p className="card-text">Price: ${product.price}</p>
                <button className="btn btn-danger" onClick={() => removeFromCart(product.id)}>Remove</button>
                <button className="btn btn-success" onClick={() => handleBuy(product)}>Buy</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Cart;
