﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerceAPI.Models
{
    public class Order
    {
        public int Id { get; set; }

        [Column("user_id")]
        public int UserId { get; set; }

        public decimal total_price { get; set; }
        public string? status { get; set; }
        public DateTime created_at { get; set; }

        public User User { get; set; }
        public ICollection<OrderItem> OrderItems { get; set; }
    }
}
