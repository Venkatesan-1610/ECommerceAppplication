﻿using ECommerceAPI.Data;
using ECommerceAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Threading.Tasks;

namespace ECommerceAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ProductsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("GetProducts")]
        public async Task<IActionResult> GetProducts()
        {
            var products = await _context.Products.ToListAsync();
            return Ok(products);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("CreateProduct")]
        public async Task<IActionResult> CreateProduct(Products product)
        {
            try
            {
                var nameParam = new SqlParameter("@Name", SqlDbType.NVarChar, 100) { Value = product.Name };
                var descriptionParam = new SqlParameter("@Description", SqlDbType.NVarChar, 500) { Value = product.Description };
                var priceParam = new SqlParameter("@Price", SqlDbType.Decimal) { Value = product.Price };
                var stockParam = new SqlParameter("@Stock", SqlDbType.Int) { Value = product.Stock };

                var productIdParam = new SqlParameter("@ProductId", SqlDbType.Int) { Direction = ParameterDirection.Output };

                await _context.Database.ExecuteSqlRawAsync("EXEC @ProductId = Create_Product @Name, @Description, @Price, @Stock",
                    nameParam, descriptionParam, priceParam, stockParam, productIdParam);

                int newProductId = (int)productIdParam.Value;
                var newProduct = await _context.Products.FindAsync(newProductId);

                return Ok(newProduct);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Failed to create product", error = ex.Message });
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateProduct(int id, Products product)
        {
            var existingProduct = await _context.Products.FindAsync(id);
            if (existingProduct == null)
                return NotFound();

            existingProduct.Name = product.Name;
            existingProduct.Description = product.Description;
            existingProduct.Price = product.Price;
            existingProduct.Stock = product.Stock;
            await _context.SaveChangesAsync();

            return Ok(existingProduct);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("DeleteProduct/{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Product deleted successfully" });
        }
    }
}
