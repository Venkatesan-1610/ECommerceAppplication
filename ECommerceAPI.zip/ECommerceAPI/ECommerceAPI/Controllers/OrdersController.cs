﻿using ECommerceAPI.Data;
using ECommerceAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerceAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public OrdersController(AppDbContext context)
        {
            _context = context;
        }

      

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetOrders()
        {
            var userId = int.Parse(User.FindFirst("id").Value);
            var orders = await _context.Orders.Where(o => o.UserId == userId).ToListAsync();
            return Ok(orders);
        }

        [Authorize]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrder(int id)
        {
            var userId = int.Parse(User.FindFirst("id").Value);
            var order = await _context.Orders.FirstOrDefaultAsync(o => o.Id == id && o.UserId == userId);

            if (order == null)
                return NotFound();

            return Ok(order);
        }

        //[Authorize]
        //[Authorize]
        [HttpPost("CreateOrder")]
        public async Task<IActionResult> CreateOrder(OrderRequest orderRequest)
        {
            try
            {
                // Validate product ID
                var product = await _context.Products.FindAsync(orderRequest.ProductId);
                if (product == null)
                {
                    return BadRequest("Invalid product ID");
                }

                // Validate user ID
                var user = await _context.Users.FindAsync(orderRequest.UserId);
                if (user == null)
                {
                    return BadRequest("Invalid user ID");
                }

                // Create order instance
                var order = new Order
                {
                    UserId = orderRequest.UserId,
                    total_price = orderRequest.Price,
                    status = "Pending",
                    created_at = DateTime.UtcNow
                };

                // Add the order to context and save changes
                _context.Orders.Add(order);
                await _context.SaveChangesAsync();

                return Ok(order);
            }
            catch (Exception ex)
            {
                // Log the exception or handle it appropriately
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


    }
}
